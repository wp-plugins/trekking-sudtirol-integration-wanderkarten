Plugin Name: Trekking Suedtirol (trekk)
Plugin URI:http://weblog.dietmar.biz/archives/157
Description: Dieses Plugin erm&ouml;glicht die einfache Integration von S&uuml;dtiroler Wandertouren in deinen Wordpressblog. Daf&uuml;r greift das Plugin auf die Schnittstelle von www.trekking.suedtirol.info zur&uuml;ck.
Author: Dietmar Mitterer-Zublasing
Author URI: http://www.compusol.it/
Version: 1.0
License: This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

Copyright 2008 Compusol des P.I. Mitterer-Zublasing Dietmar

Achtung ich &uuml;berneheme keine Haftung f&uuml;r wenn durch dein Einsatz dieses Plugins Sch&auml;den finanzieller oder ideeller oder jeglicher anderer Art entstehen. Der Einsatz dieses Plugin erfolgt auf eigene Gefahr!

Installationshinweise siehe: http://weblog.dietmar.biz/archives/157 


